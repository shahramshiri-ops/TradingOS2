/* SHADOW-PANEL-03B / COUNT-NORMALIZE-01 v1.0
   Unified Shadow card with corrected count semantics.
   Boundary: NOT_SIGNAL / NO_BUY_SELL / NO_ENTRY_STOP_TARGET / NO_BROKER_EXECUTION / NO_AUTO_LEARNING / NO_RULE_REWRITE.
*/
(function () {
  "use strict";

  const PATCH_ID = "SHADOW_PANEL_03B_COUNT_NORMALIZE_v1_0";

  const STATUS_PATHS = [
    "shadow_panel_status_current.json",
    "./shadow_panel_status_current.json",
    "../../runtime/sig_shadow/shadow_panel_status_current.json"
  ];

  const OPS_PATHS = [
    "shadow_ops_status_current.json",
    "./shadow_ops_status_current.json",
    "../../runtime/sig_shadow/shadow_ops_status_current.json"
  ];

  const COUNT_PATHS = [
    "shadow_count_semantics_current.json",
    "./shadow_count_semantics_current.json",
    "../../runtime/sig_shadow/shadow_count_semantics_current.json"
  ];

  function bust(url) {
    return url + (url.includes("?") ? "&" : "?") + "t=" + Date.now();
  }

  async function fetchJsonAny(paths) {
    const errors = [];
    for (const p of paths) {
      try {
        const resp = await fetch(bust(p), { cache: "no-store" });
        if (!resp.ok) {
          errors.push(`${p}: HTTP ${resp.status}`);
          continue;
        }
        return { data: await resp.json(), source: p, errors };
      } catch (e) {
        errors.push(`${p}: ${e && e.message ? e.message : String(e)}`);
      }
    }
    return { data: null, source: null, errors };
  }

  function n(v, fallback = 0) {
    const x = Number(v);
    return Number.isFinite(x) ? x : fallback;
  }

  function txt(v, fallback = "—") {
    if (v === undefined || v === null || v === "") return fallback;
    return String(v);
  }

  function hasBoundaryViolation(data) {
    return !!(data && (
      data.signal_authorized ||
      data.trade_instruction_authorized ||
      data.broker_execution_authorized ||
      data.action_surface_authorized ||
      data.auto_learning_authorized ||
      data.rule_rewrite_authorized
    ));
  }

  function statusClass(health) {
    const h = String(health || "").toUpperCase();
    if (h === "PASS") return "unified-pass";
    if (h === "WARN") return "unified-warn";
    if (h === "FAIL" || h.includes("FAIL")) return "unified-fail";
    return "unified-neutral";
  }

  function mergeData(status, ops, count) {
    const boundaryBad = hasBoundaryViolation(status) || hasBoundaryViolation(ops) || hasBoundaryViolation(count);
    const health = boundaryBad ? "FAIL" : txt((ops && ops.health_status) || (status && status.shadow_system_status), "UNKNOWN");

    const diagnosticRecords = n(count && count.diagnostic_record_count_last_run, n(ops && ops.near_miss_count_last_run, n(status && status.near_miss_count_last_run)));
    const uniqueMarketNearMiss = n(count && count.unique_market_near_miss_event_count_last_run, 0);

    return {
      health_status: health,
      created_utc: txt((count && count.created_utc) || (ops && ops.created_utc) || (status && status.created_utc)),
      display_badge: boundaryBad ? "BOUNDARY VIOLATION" : txt((ops && ops.display_badge) || (status && status.display_badge), "SHADOW / NOT A SIGNAL"),

      candidate_count: n((count && count.candidate_count), n((ops && ops.candidate_count), n(status && status.candidate_count))),
      diagnostic_record_count: diagnosticRecords,
      unique_market_near_miss_count: uniqueMarketNearMiss,
      unique_memory_count: n(count && count.unique_memory_involved_count_last_run),
      blocker_diagnostic_count: n(count && count.blocker_diagnostic_record_count_last_run, n(ops && ops.blocked_candidate_count_last_run)),
      instrumentation_gap_count: n(count && count.instrumentation_gap_record_count_last_run),
      eligibility_record_count: n(count && count.eligibility_record_count_last_run),
      lifecycle_record_count: n(count && count.lifecycle_record_count_last_run),

      raw_near_miss_count_from_ops: n(count && count.raw_near_miss_count_from_ops, n(ops && ops.near_miss_count_last_run)),
      raw_near_miss_high_count_from_ops: n(count && count.raw_near_miss_high_count_from_ops, n(ops && ops.near_miss_high_count_last_run, n(status && status.near_miss_high_count_last_run))),

      observation_count: n(status && status.observation_count),
      observation_pending_count: n(status && status.observation_pending_count),
      observation_complete_count: n(status && status.observation_complete_count),

      active_watch_count: n(count && count.active_watch_count),
      active_core_count: n(count && count.active_core_eligible_watch_count, n(ops && ops.active_watch_core_eligible_count)),
      active_extended_count: n(count && count.active_extended_only_watch_count, n(ops && ops.active_watch_extended_observation_only_count)),
      active_non_core_count: n(count && count.active_non_core_watch_count),

      top_reason_breakdown: (count && count.reason_breakdown && typeof count.reason_breakdown === "object")
        ? Object.entries(count.reason_breakdown)
        : ((ops && Array.isArray(ops.top_reason_breakdown)) ? ops.top_reason_breakdown : []),

      top_count_class_breakdown: (count && count.record_class_breakdown && typeof count.record_class_breakdown === "object")
        ? Object.entries(count.record_class_breakdown)
        : ((ops && Array.isArray(ops.top_count_class_breakdown)) ? ops.top_count_class_breakdown : []),

      daily_rollup_latest: (ops && ops.daily_rollup_latest) || null,
      weekly_rollup_latest: (ops && ops.weekly_rollup_latest) || null,
      cohort_rollup: (ops && ops.cohort_rollup) || null,
      review_item_count: n(ops && ops.review_item_count),
      plain_language_fa: txt((count && count.plain_language_fa) || (ops && ops.plain_language_fa) || (status && status.plain_language_fa), "این بخش فقط وضعیت shadow را نشان می‌دهد و سیگنال معامله نیست."),
      count_semantics_available: !!count,
      status_source_available: !!status,
      ops_source_available: !!ops,
      boundary_violation: boundaryBad
    };
  }

  function quickInterpretation(d) {
    if (d.boundary_violation) {
      return "هشدار مرزی: یکی از payloadها مجوز نامعتبر دارد. این خروجی نباید برای تصمیم معاملاتی استفاده شود.";
    }
    if (String(d.health_status).toUpperCase() === "FAIL") {
      return "سلامت pipeline مشکل جدی دارد؛ قبل از تفسیر candidate یا recordها باید health بررسی شود.";
    }
    if (d.candidate_count > 0) {
      return "کاندید shadow ثبت شده است؛ هنوز سیگنال نیست و فقط باید observationهای بعدی تکمیل شوند.";
    }
    if (d.unique_market_near_miss_count > 0) {
      return "near-miss واقعی بازار داریم، اما هنوز candidate کامل نشده؛ باید stage/reason بررسی شود.";
    }
    if (d.diagnostic_record_count > 0) {
      return "عددهای قبلی near-miss بیشتر diagnostic record هستند، نه فرصت واقعی بازار. سیستم هنوز candidate واقعی ندارد.";
    }
    return "فعلاً candidate یا diagnostic مهمی دیده نمی‌شود؛ این به معنی خرابی سیستم نیست.";
  }

  function formatPairs(list, empty) {
    if (!Array.isArray(list) || !list.length) {
      return `<div class="shadow-unified-empty">${empty || "موردی ثبت نشده است."}</div>`;
    }
    return `<div class="shadow-unified-pairs">` + list.slice(0, 6).map((x) => {
      const k = Array.isArray(x) ? x[0] : (x && (x.key || x.reason || x.stage)) || "UNKNOWN";
      const v = Array.isArray(x) ? x[1] : (x && (x.count || x.value)) || 0;
      return `<div class="shadow-unified-pair"><span>${txt(k)}</span><b>${txt(v, "0")}</b></div>`;
    }).join("") + `</div>`;
  }

  function rollupBlock(title, roll, fallbackLabel) {
    const r = roll || {};
    return `
      <div class="shadow-unified-roll">
        <span>${title}</span>
        <b>${n(r.near_miss_count)}</b>
        <small>diagnostic records · ${txt(r.period || r.cohort_id, fallbackLabel)} · ${n(r.run_count)} run</small>
      </div>`;
  }

  function removeOldHosts() {
    ["shadow-panel-01-host", "shadow-panel-02-ops-host"].forEach((id) => {
      const el = document.getElementById(id);
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  function ensureHost() {
    removeOldHosts();
    let host = document.getElementById("shadow-panel-03-unified-host");
    if (host) return host;

    host = document.createElement("section");
    host.id = "shadow-panel-03-unified-host";
    host.className = "shadow-panel-03-unified-host";

    const anchors = [
      document.querySelector("[data-shadow-panel-anchor]"),
      document.querySelector("#active-events"),
      document.querySelector(".active-events"),
      document.querySelector("main"),
      document.querySelector(".container"),
      document.body
    ].filter(Boolean);

    const parent = anchors[0] || document.body;
    if (parent === document.body || parent.tagName.toLowerCase() === "main") {
      parent.insertBefore(host, parent.firstChild);
    } else if (parent.parentNode) {
      parent.parentNode.insertBefore(host, parent.nextSibling);
    } else {
      document.body.insertBefore(host, document.body.firstChild);
    }
    return host;
  }

  function renderLoading(host) {
    host.innerHTML = `<div class="shadow-unified-card unified-neutral" dir="rtl"><div class="shadow-unified-muted">در حال خواندن وضعیت Shadow...</div></div>`;
  }

  function renderMissing(host, results) {
    const errors = results.flatMap(r => (r && r.errors) || []);
    host.innerHTML = `
      <div class="shadow-unified-card unified-neutral" dir="rtl">
        <div class="shadow-unified-head">
          <div>
            <div class="shadow-unified-kicker">Shadow / Count Semantics</div>
            <h3>وضعیت Shadow در دسترس نیست</h3>
          </div>
          <span class="shadow-unified-badge">NOT A SIGNAL</span>
        </div>
        <p class="shadow-unified-muted">فایل‌های وضعیت shadow هنوز deploy نشده‌اند یا در دسترس نیستند.</p>
        <details class="shadow-unified-details"><summary>خطاهای خواندن فایل</summary><pre>${errors.map(String).join("\n")}</pre></details>
      </div>`;
  }

  function render(host, d, sources) {
    const cls = statusClass(d.health_status);
    const rawDiffers = d.raw_near_miss_count_from_ops !== d.unique_market_near_miss_count;
    host.innerHTML = `
      <div class="shadow-unified-card ${cls}" dir="rtl">
        <div class="shadow-unified-head">
          <div>
            <div class="shadow-unified-kicker">Live Shadow / Count Semantics</div>
            <h3>Shadow زنده</h3>
          </div>
          <div class="shadow-unified-badges">
            <span class="shadow-unified-badge">${txt(d.display_badge, "SHADOW / NOT A SIGNAL")}</span>
            <span class="shadow-unified-health">${txt(d.health_status, "UNKNOWN")}</span>
          </div>
        </div>

        <div class="shadow-unified-quick">
          <span class="shadow-unified-dot"></span>
          <strong>برداشت سریع:</strong>
          <span>${quickInterpretation(d)}</span>
        </div>

        ${rawDiffers ? `<div class="shadow-unified-warning">اصلاح شمارش: near-miss خام (${d.raw_near_miss_count_from_ops}) برابر فرصت واقعی بازار نیست. تعداد near-miss یکتای بازار فعلاً ${d.unique_market_near_miss_count} است.</div>` : ""}

        <div class="shadow-unified-metrics">
          <div class="shadow-unified-metric primary">
            <span>کاندید shadow</span>
            <b>${d.candidate_count}</b>
            <small>واقعاً وارد shadow ledger شده</small>
          </div>
          <div class="shadow-unified-metric">
            <span>diagnostic records</span>
            <b>${d.diagnostic_record_count}</b>
            <small>ردیف تشخیصی، نه فرصت</small>
          </div>
          <div class="shadow-unified-metric attention">
            <span>market near-miss</span>
            <b>${d.unique_market_near_miss_count}</b>
            <small>رخداد یکتای نزدیک به candidate</small>
          </div>
          <div class="shadow-unified-metric">
            <span>unique memories</span>
            <b>${d.unique_memory_count}</b>
            <small>memoryهای درگیر</small>
          </div>
          <div class="shadow-unified-metric">
            <span>blocker diagnostics</span>
            <b>${d.blocker_diagnostic_count}</b>
            <small>recordهای blocker</small>
          </div>
          <div class="shadow-unified-metric">
            <span>instrumentation gaps</span>
            <b>${d.instrumentation_gap_count}</b>
            <small>reason دقیق تولید نشده</small>
          </div>
        </div>

        <div class="shadow-unified-metrics shadow-unified-secondary">
          <div class="shadow-unified-metric">
            <span>active watches</span>
            <b>${d.active_watch_count}</b>
            <small>core ${d.active_core_count} / extended ${d.active_extended_count} / non-core ${d.active_non_core_count}</small>
          </div>
          <div class="shadow-unified-metric">
            <span>eligibility records</span>
            <b>${d.eligibility_record_count}</b>
            <small>out-of-core / non-core</small>
          </div>
          <div class="shadow-unified-metric">
            <span>lifecycle records</span>
            <b>${d.lifecycle_record_count}</b>
            <small>expired / invalidated</small>
          </div>
          <div class="shadow-unified-metric">
            <span>observation</span>
            <b>${d.observation_count}</b>
            <small>${d.observation_pending_count} pending / ${d.observation_complete_count} complete</small>
          </div>
        </div>

        <div class="shadow-unified-split">
          <div class="shadow-unified-panel">
            <h4>نوع recordها</h4>
            ${formatPairs(d.top_count_class_breakdown, "نوعی ثبت نشده است.")}
          </div>
          <div class="shadow-unified-panel">
            <h4>علت‌های اصلی</h4>
            ${formatPairs(d.top_reason_breakdown, "علتی ثبت نشده است.")}
          </div>
        </div>

        <details class="shadow-unified-details">
          <summary>Rollup و review</summary>
          <div class="shadow-unified-rollups">
            ${rollupBlock("امروز", d.daily_rollup_latest, "today")}
            ${rollupBlock("هفته", d.weekly_rollup_latest, "week")}
            ${rollupBlock("cohort", d.cohort_rollup, "cohort")}
            <div class="shadow-unified-roll">
              <span>review queue</span>
              <b>${d.review_item_count}</b>
              <small>مورد برای PMO review</small>
            </div>
          </div>
        </details>

        <details class="shadow-unified-details">
          <summary>جزئیات فنی و مرزها</summary>
          <div class="shadow-unified-detail-grid">
            <div><span>created</span><b>${txt(d.created_utc)}</b></div>
            <div><span>count semantics</span><b>${txt(sources.count)}</b></div>
            <div><span>status source</span><b>${txt(sources.status)}</b></div>
            <div><span>ops source</span><b>${txt(sources.ops)}</b></div>
            <div><span>count semantics available</span><b>${txt(d.count_semantics_available)}</b></div>
            <div><span>boundary</span><b>NO_SIGNAL / NO_EXECUTION</b></div>
          </div>
          <p class="shadow-unified-muted">${txt(d.plain_language_fa)}</p>
        </details>
      </div>
    `;
  }

  async function init() {
    const host = ensureHost();
    renderLoading(host);

    const [statusResult, opsResult, countResult] = await Promise.all([
      fetchJsonAny(STATUS_PATHS),
      fetchJsonAny(OPS_PATHS),
      fetchJsonAny(COUNT_PATHS)
    ]);

    if (!statusResult.data && !opsResult.data && !countResult.data) {
      renderMissing(host, [statusResult, opsResult, countResult]);
      return;
    }

    const d = mergeData(statusResult.data, opsResult.data, countResult.data);
    render(host, d, { status: statusResult.source, ops: opsResult.source, count: countResult.source });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.SIG_SHADOW_PANEL_03B = { patchId: PATCH_ID, reload: init };
})();
